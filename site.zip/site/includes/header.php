<header class="top-menu">

			<ul>
				<li class="top-menu__item"><a class="top-menu__link--store" href="/site/">furnitureStore</a></li>
				<li class="top-menu__item"><a class="top-menu__link" href="#">Shop</a></li>
				<li class="top-menu__item"><a class="top-menu__link" href="#">About</a></li>
				<li class="top-menu__item"><a class="top-menu__link" href="#">Newsletter</a></li>
				<li class="top-menu__item"><a class="top-menu__link" href="contact.php">Contact Us</a></li>
				<li class="top-menu__item"><a class="top-menu__link" href="#">Blog</a></li>
			</ul>

		</header>
