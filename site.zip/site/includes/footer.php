<footer class="footer">
	<p class="footer__txt">&copy; Arnaud</p>
</footer>