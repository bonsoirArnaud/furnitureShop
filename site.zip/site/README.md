# furnitureShop

furnitureShop is a simple website made with HTML, PHP and jQuery.