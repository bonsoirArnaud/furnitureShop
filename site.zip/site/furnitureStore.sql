-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Jeu 14 Avril 2016 à 11:20
-- Version du serveur :  5.5.42
-- Version de PHP :  5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de données :  `furnitureStore`
--

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `stock` int(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `img`) VALUES
(1, 'Forhoja', 'Phasellus consequat pretium odio non laoreet. Donec rhoncus, massa et consequat vehicula, sapien mauris auctor massa, commodo eleifend ex magna eget diam. Aenean rhoncus, eros eu ultrices gravida, nisl lacus bibendum libero, non lacinia lacus sapien vel nunc.', '1,399.00', 12, 'forhoja.jpg'),
(2, 'Grundtal', 'Donec vestibulum orci feugiat sagittis sollicitudin. Proin fringilla diam sit amet porttitor elementum. Integer eu est in odio bibendum posuere.', '1,829.00', 3, 'grundtal.jpg'),
(3, 'Norraker', 'Nullam iaculis euismod orci non cursus. Maecenas tristique neque est, et hendrerit ligula congue lobortis. Pellentesque porttitor tincidunt blandit. Suspendisse ac luctus est, sit amet egestas est.', '1,449.00', 7, 'norraker.jpg');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;