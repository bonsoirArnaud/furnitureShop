<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact Us - furnitureStore</title>
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="container">
		<?php include 'includes/header.php'; ?>
		<img src="img/contact.jpg" />
		
		<div class="form-contact">
			
			<h2 class="h2-title">Contact Us</h2>

			<form action="process.php" method="POST" class="form-contat__form">

				<input class="form-contact__input" name="name" type="text" placeholder="Name"/>
				<input class="form-contact__input" name="first-name" type="text" placeholder="First name"/>
				<input class="form-contact__input" name="e-mail" type="text" placeholder="E-mail"/>
				<textarea class="form-contact__input form-contact__input--textarea" name="message" placeholder="Message"></textarea>

				<button class="form-contact__button" type="submit">Send</button>
			</form>
		
		</div>



		<?php include 'includes/footer.php'; ?>
	</div>
	<script type="text/javascript" src="js/jquery-1.12.3.min.js"></script>
</body>
</html>