<?php
try {
	$user = 'root';
	$pass = 'root';
    $dbh = new PDO('mysql:host=localhost;dbname=furnitureStore', $user, $pass);
} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>furnitureStore</title>
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="container">
		<?php include 'includes/header.php'; ?>
		<img src="img/home.jpg" alt="furnitureStore" />

		<div class="about-furniture">
			<h2 class="h2-title">About</h2>
			<p class="about-furniture__description">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus arcu velit, convallis nec tincidunt ut, scelerisque id justo.</p>
			<img src="img/stars.png" />
		</div>

		<div class="products-collection">
			<h2 class="h2-title">Shop our products</h2>
			<div class="product-list">
			<?php

			$stmt = $dbh->prepare("SELECT * FROM products"); 
			$stmt->execute();
			$products = $stmt->fetchAll();

			foreach ($products as $product) {
        		echo '<div class="product-list__item">
        				<a href="product.php?id=' . $product['id'] . '" class="product-list__item--link">
        					<img class="product-list__item--img" src="img/' . $product['img'] .'"/>
        				</a>
        				<div class="product-list__item--name">' . $product['name'] . '</div>
        				<div class="product-list__item--price">from ' . $product['price'] . '€</div>
        			</div>';
    		}

    		?>
			</div>
		</div>

		<?php include 'includes/footer.php'; ?>
	</div>
	<script type="text/javascript" src="js/jquery-1.12.3.min.js"></script>
</body>
</html>