<?php
try {
	$user = 'root';
	$pass = 'root';
    $dbh = new PDO('mysql:host=localhost;dbname=furnitureStore', $user, $pass);
} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}

$id = $_GET['id'];

$stmt = $dbh->prepare("SELECT * FROM products WHERE id=$id"); 
$stmt->execute(); 
$product = $stmt->fetch();

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $product['name']; ?> - furnitureStore</title>
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="container">
		<?php include 'includes/header.php'; ?>
		
		<div class="product-details">

			<?php
 
			echo '<div class="product-details__img-large">
					<img class="product-details__img-large--img" src="img/' . $product['img'] .'"/>
				</div>
				<div class="product-details__product-name">' . $product['name'] . '</div>
				<p class="product-details__product-description">' . $product['description'] . '</p>
				<p class="product-details__product-description--stock">Stock : ' . $product['stock'] . '</p>
				<div class="product-details__product-price">' . $product['price'] . '€</div>';
		
			?>

			<a class="product-details__add-to-cart">Add to cart</a>

		</div>

		<?php include 'includes/footer.php'; ?>
	</div>
	<script type="text/javascript" src="js/jquery-1.12.3.min.js"></script>
	<script type="text/javascript">

	$('.product-details__add-to-cart').on('click',function(){
		var stock = '<?php echo $product['stock'] - 1 ?>';
		$('.product-details__product-description').html("<?php echo $product['name']; ?> was added to cart.");
		$('.product-details__product-description--stock').html('Stock : ' + stock);
	});

	</script>
</body>
</html>